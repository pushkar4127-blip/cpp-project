#ifndef INVENTORY_MANAGER_H
#define INVENTORY_MANAGER_H

#include <string>
#include <vector>
#include <algorithm>
#include <cstring>
#include "inventory.h"

class InventoryManager {
public:
    InventoryManager();

    bool addItem(int id, const std::string& name, int quantity, float price);
    bool viewItem(int id);
    bool updateItem(int id, const std::string& name, int quantity, float price);
    bool deleteItem(int id);
    void listAll(const std::string& sortBy = "id");
};

#endif /* INVENTORY_MANAGER_H */
