#include "InventoryManager.h"
#include <iostream>
#include <algorithm>
#include <iomanip>

#define MAX_ITEMS 1000

InventoryManager::InventoryManager() {}

bool InventoryManager::addItem(int id, const std::string& name, int quantity, float price) {
    if (id <= 0) {
        std::cout << "[Error] ID must be positive.\n";
        return false;
    }
    if (quantity < 0) {
        std::cout << "[Error] Quantity must be 0 or more.\n";
        return false;
    }
    if (price < 0) {
        std::cout << "[Error] Price must be 0 or more.\n";
        return false;
    }
    if (name.empty()) {
        std::cout << "[Error] Name must not be empty.\n";
        return false;
    }

    Item item;
    item.id = id;
    item.quantity = quantity;
    item.price = price;
    item.is_deleted = 0;
    strncpy(item.name, name.c_str(), 39);
    item.name[39] = '\0';

    int result = add_item(&item);
    if (result) {
        std::cout << "[Success] Item added with ID " << id << ".\n";
    } else {
        std::cout << "[Error] Failed to add item. Duplicate ID or file error.\n";
    }
    return result == 1;
}

bool InventoryManager::viewItem(int id) {
    if (id <= 0) {
        std::cout << "[Error] ID must be positive.\n";
        return false;
    }
    Item out;
    int result = get_item(id, &out);
    if (result) {
        std::cout << "\n--- Item Details ---\n";
        std::cout << "  ID       : " << out.id << "\n";
        std::cout << "  Name     : " << out.name << "\n";
        std::cout << "  Quantity : " << out.quantity << "\n";
        std::cout << std::fixed << std::setprecision(2);
        std::cout << "  Price    : $" << out.price << "\n";
        std::cout << "--------------------\n";
    } else {
        std::cout << "[Error] Item with ID " << id << " not found or deleted.\n";
    }
    return result == 1;
}

bool InventoryManager::updateItem(int id, const std::string& name, int quantity, float price) {
    if (id <= 0) {
        std::cout << "[Error] ID must be positive.\n";
        return false;
    }
    if (quantity < 0) {
        std::cout << "[Error] Quantity must be 0 or more.\n";
        return false;
    }
    if (price < 0) {
        std::cout << "[Error] Price must be 0 or more.\n";
        return false;
    }
    if (name.empty()) {
        std::cout << "[Error] Name must not be empty.\n";
        return false;
    }

    Item updated;
    updated.id = id;
    updated.quantity = quantity;
    updated.price = price;
    updated.is_deleted = 0;
    strncpy(updated.name, name.c_str(), 39);
    updated.name[39] = '\0';

    int result = update_item(id, &updated);
    if (result) {
        std::cout << "[Success] Item ID " << id << " updated.\n";
    } else {
        std::cout << "[Error] Item with ID " << id << " not found or deleted.\n";
    }
    return result == 1;
}

bool InventoryManager::deleteItem(int id) {
    if (id <= 0) {
        std::cout << "[Error] ID must be positive.\n";
        return false;
    }
    int result = delete_item(id);
    if (result) {
        std::cout << "[Success] Item ID " << id << " deleted.\n";
    } else {
        std::cout << "[Error] Item with ID " << id << " not found or already deleted.\n";
    }
    return result == 1;
}

void InventoryManager::listAll(const std::string& sortBy) {
    Item buffer[MAX_ITEMS];
    int count = list_items(buffer, MAX_ITEMS);

    if (count == 0) {
        std::cout << "[Info] No active items in inventory.\n";
        return;
    }

    /* Use std::vector to hold items temporarily */
    std::vector<Item> items(buffer, buffer + count);

    /* Use std::sort to sort by id or name */
    if (sortBy == "name") {
        std::sort(items.begin(), items.end(), [](const Item& a, const Item& b) {
            return std::string(a.name) < std::string(b.name);
        });
    } else {
        std::sort(items.begin(), items.end(), [](const Item& a, const Item& b) {
            return a.id < b.id;
        });
    }

    std::cout << "\n====== Inventory List (" << count << " item(s)) ======\n";
    std::cout << std::left
              << std::setw(6)  << "ID"
              << std::setw(22) << "Name"
              << std::setw(10) << "Quantity"
              << std::setw(10) << "Price"
              << "\n";
    std::cout << std::string(50, '-') << "\n";
    std::cout << std::fixed << std::setprecision(2);
    for (const auto& item : items) {
        std::cout << std::left
                  << std::setw(6)  << item.id
                  << std::setw(22) << item.name
                  << std::setw(10) << item.quantity
                  << "$" << item.price
                  << "\n";
    }
    std::cout << std::string(50, '=') << "\n";
}
