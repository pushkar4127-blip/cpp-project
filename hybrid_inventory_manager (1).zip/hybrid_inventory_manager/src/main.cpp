#include <iostream>
#include <limits>
#include <string>
#include "InventoryManager.h"

/* Input helpers */
int getPositiveInt(const std::string& prompt) {
    int val;
    while (true) {
        std::cout << prompt;
        if (std::cin >> val && val > 0) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return val;
        }
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "[Error] Please enter a positive integer.\n";
    }
}

int getNonNegativeInt(const std::string& prompt) {
    int val;
    while (true) {
        std::cout << prompt;
        if (std::cin >> val && val >= 0) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return val;
        }
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "[Error] Please enter 0 or more.\n";
    }
}

float getNonNegativeFloat(const std::string& prompt) {
    float val;
    while (true) {
        std::cout << prompt;
        if (std::cin >> val && val >= 0) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return val;
        }
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "[Error] Please enter 0 or more.\n";
    }
}

std::string getNonEmptyString(const std::string& prompt) {
    std::string val;
    while (true) {
        std::cout << prompt;
        std::getline(std::cin, val);
        if (!val.empty()) return val;
        std::cout << "[Error] Name must not be empty.\n";
    }
}

void printMenu() {
    std::cout << "\n=============================\n";
    std::cout << "  Hybrid Inventory Manager\n";
    std::cout << "=============================\n";
    std::cout << "  1. Add item\n";
    std::cout << "  2. View item\n";
    std::cout << "  3. Update item\n";
    std::cout << "  4. Delete item\n";
    std::cout << "  5. List all\n";
    std::cout << "  6. Exit\n";
    std::cout << "=============================\n";
    std::cout << "Choice: ";
}

int main() {
    InventoryManager mgr;
    int choice;

    std::cout << "Welcome to the Hybrid Inventory Manager!\n";

    while (true) {
        printMenu();

        if (!(std::cin >> choice)) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "[Error] Invalid input. Enter a number 1-6.\n";
            continue;
        }
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        switch (choice) {
            case 1: {
                std::cout << "\n-- Add Item --\n";
                int id       = getPositiveInt("  ID       : ");
                std::string name = getNonEmptyString("  Name     : ");
                int qty      = getNonNegativeInt("  Quantity : ");
                float price  = getNonNegativeFloat("  Price    : ");
                mgr.addItem(id, name, qty, price);
                break;
            }
            case 2: {
                std::cout << "\n-- View Item --\n";
                int id = getPositiveInt("  ID: ");
                mgr.viewItem(id);
                break;
            }
            case 3: {
                std::cout << "\n-- Update Item --\n";
                int id       = getPositiveInt("  ID       : ");
                std::string name = getNonEmptyString("  New Name : ");
                int qty      = getNonNegativeInt("  Quantity : ");
                float price  = getNonNegativeFloat("  Price    : ");
                mgr.updateItem(id, name, qty, price);
                break;
            }
            case 4: {
                std::cout << "\n-- Delete Item --\n";
                int id = getPositiveInt("  ID: ");
                mgr.deleteItem(id);
                break;
            }
            case 5: {
                std::cout << "\nSort by: (1) ID  (2) Name\nChoice: ";
                int s;
                std::string sortBy = "id";
                if (std::cin >> s) {
                    if (s == 2) sortBy = "name";
                }
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                mgr.listAll(sortBy);
                break;
            }
            case 6: {
                std::cout << "Goodbye!\n";
                return 0;
            }
            default:
                std::cout << "[Error] Please enter a number between 1 and 6.\n";
        }
    }
    return 0;
}
