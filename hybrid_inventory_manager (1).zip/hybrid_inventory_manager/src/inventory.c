#include <stdio.h>
#include <string.h>
#include "inventory.h"

#define DATA_FILE "inventory.dat"

/* Add a new item to the binary file. Returns 1 on success, 0 on failure. */
int add_item(const Item* item) {
    if (!item) return 0;

    /* Check for duplicate ID */
    Item temp;
    if (get_item(item->id, &temp) == 1) {
        return 0; /* Duplicate ID rejected */
    }

    FILE* fp = fopen(DATA_FILE, "ab");
    if (!fp) return 0;

    size_t written = fwrite(item, sizeof(Item), 1, fp);
    fclose(fp);
    return (written == 1) ? 1 : 0;
}

/* Get a single active item by ID. Returns 1 if found, 0 otherwise. */
int get_item(int id, Item* out) {
    if (!out) return 0;

    FILE* fp = fopen(DATA_FILE, "rb");
    if (!fp) return 0;

    Item temp;
    while (fread(&temp, sizeof(Item), 1, fp) == 1) {
        if (temp.id == id && temp.is_deleted == 0) {
            *out = temp;
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}

/* Update an existing item by ID. Returns 1 on success, 0 on failure. */
int update_item(int id, const Item* updated) {
    if (!updated) return 0;

    FILE* fp = fopen(DATA_FILE, "r+b");
    if (!fp) return 0;

    Item temp;
    long offset = 0;
    while (fread(&temp, sizeof(Item), 1, fp) == 1) {
        if (temp.id == id && temp.is_deleted == 0) {
            fseek(fp, offset, SEEK_SET);
            Item new_item = *updated;
            new_item.id = id; /* preserve original ID */
            new_item.is_deleted = 0;
            size_t written = fwrite(&new_item, sizeof(Item), 1, fp);
            fclose(fp);
            return (written == 1) ? 1 : 0;
        }
        offset += sizeof(Item);
    }
    fclose(fp);
    return 0;
}

/* Soft-delete an item by ID. Returns 1 on success, 0 if not found. */
int delete_item(int id) {
    FILE* fp = fopen(DATA_FILE, "r+b");
    if (!fp) return 0;

    Item temp;
    long offset = 0;
    while (fread(&temp, sizeof(Item), 1, fp) == 1) {
        if (temp.id == id && temp.is_deleted == 0) {
            temp.is_deleted = 1;
            fseek(fp, offset, SEEK_SET);
            fwrite(&temp, sizeof(Item), 1, fp);
            fclose(fp);
            return 1;
        }
        offset += sizeof(Item);
    }
    fclose(fp);
    return 0;
}

/* List all active (non-deleted) items into buffer. Returns count copied. */
int list_items(Item* buffer, int max_items) {
    if (!buffer || max_items <= 0) return 0;

    FILE* fp = fopen(DATA_FILE, "rb");
    if (!fp) return 0;

    Item temp;
    int count = 0;
    while (count < max_items && fread(&temp, sizeof(Item), 1, fp) == 1) {
        if (temp.is_deleted == 0) {
            buffer[count++] = temp;
        }
    }
    fclose(fp);
    return count;
}
