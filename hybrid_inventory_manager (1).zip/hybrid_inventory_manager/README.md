# Hybrid Inventory Manager

A console-based inventory management system with a **C data layer** (binary file storage) and a **C++ UI/logic layer** (STL, class-based menu).

---

## File Structure

```
hybrid_inventory_manager/
├── include/
│   ├── inventory.h          # C struct + function declarations
│   └── InventoryManager.h   # C++ class declaration
├── src/
│   ├── inventory.c          # C backend: binary file CRUD with fread/fwrite/fseek
│   ├── InventoryManager.cpp # C++ class: wraps C functions, uses vector + sort
│   └── main.cpp             # C++ main: menu loop, input validation
├── Makefile
└── README.md
```

---

## Build & Run Steps

### Prerequisites
- GCC / G++ (C11 + C++11 support)
- Make

### Build
```bash
make
```

### Run
```bash
./inventory_manager
```

### Clean
```bash
make clean
```

---

## Test Cases

- **Test 1 – Add & Persist**: Add 3 items (IDs 1, 2, 3), exit, re-run → List all shows all 3 items.
- **Test 2 – View by ID**: Add item ID 5, view ID 5 → correct details shown; view ID 99 → "not found" error.
- **Test 3 – Update persists**: Update item ID 1 with new name/price, exit, re-run → updated values appear in list.
- **Test 4 – Soft delete**: Delete item ID 2, list all → ID 2 does not appear; view ID 2 → "not found".
- **Test 5 – Duplicate rejection**: Try to add item with ID already in use → error "Duplicate ID rejected", no duplicate stored.

---

## Notes
- Data is stored in `inventory.dat` (binary) in the working directory.
- Deleted items are soft-deleted (`is_deleted = 1`) and never shown in list or view.
- List can be sorted by ID or Name using `std::sort`.
